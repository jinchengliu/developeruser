//
//  AppDelegate.h
//  PCGestureUnlock
//
//  Created by panchao on 15/6/10.
//  Copyright (c) 2015年 coderMonkey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

