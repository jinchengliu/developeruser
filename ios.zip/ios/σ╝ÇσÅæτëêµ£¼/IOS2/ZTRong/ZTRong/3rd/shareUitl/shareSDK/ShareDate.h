//
//  ShareDate.h
//  NewProduct
//
//  Created by ysy on 14/12/18.
//  Copyright (c) 2014年 Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShareDate : NSObject

@property (nonatomic,strong)NSString *content;
@property (nonatomic,strong)NSString *desc;
@property (nonatomic,strong)NSString *smsContent;
@property (nonatomic,strong)NSString *emailContent;

@end
