//
//  ShareDate.m
//  NewProduct
//
//  Created by ysy on 14/12/18.
//  Copyright (c) 2014年 Lee. All rights reserved.
//

#import "ShareDate.h"


@implementation ShareDate

-(id)init{
    self=[super init];
    if(self){
        self.content=@"";
        self.desc=@"中投融";
        
    }
    
    return  self;
}


@end
