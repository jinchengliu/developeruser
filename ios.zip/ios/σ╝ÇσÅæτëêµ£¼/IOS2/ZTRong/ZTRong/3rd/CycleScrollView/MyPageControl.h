//
//  MyPageControl.h
//  
#import <UIKit/UIKit.h>

@protocol MyPageControlDelegate <NSObject>

@optional

- (void)pageControlDidStopAtIndex:(NSInteger)index;

@end

@interface MyPageControl : UIView 
{
    UIImage         *_normalDotImage;
    UIImage         *_highlightedDotImage;
    NSInteger       __pageNumbers;
    float           __dotsSize;
    NSInteger       __dotsGap;
    id<MyPageControlDelegate> delegate;
}

@property (nonatomic , assign)NSInteger pageNumbers;
@property (nonatomic , assign) IBOutlet id<MyPageControlDelegate> delegate;
- (id)initWithFrame:(CGRect)frame
        normalImage:(UIImage *)nImage
   highlightedImage:(UIImage *)hImage
         dotsNumber:(NSInteger)pageNum
         sideLength:(NSInteger)size
            dotsGap:(NSInteger)gap;

- (void)setCurrentPage:(NSInteger)pages;

@end
