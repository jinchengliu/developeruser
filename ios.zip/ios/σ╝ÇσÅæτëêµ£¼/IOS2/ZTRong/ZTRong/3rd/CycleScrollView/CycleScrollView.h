//
//  CycleScrollView.h
//  PagedScrollView
//


#import <UIKit/UIKit.h>

@interface CycleScrollView : UIView

@property (nonatomic , readonly) UIScrollView *scrollView;

- (id)initWithFrame:(CGRect)frame animationDuration:(NSTimeInterval)animationDuration;


@property (nonatomic , copy) NSInteger (^totalPagesCount)(void);


@property (nonatomic , copy) UIView *(^fetchContentViewAtIndex)(NSInteger pageIndex);


@property (nonatomic , copy) void (^TapActionBlock)(NSInteger pageIndex);

@end