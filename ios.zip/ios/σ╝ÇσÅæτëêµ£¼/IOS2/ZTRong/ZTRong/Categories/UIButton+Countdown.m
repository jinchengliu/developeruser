//  定时器button
//  UIButton+Countdown.m
//  ZTRong
//
//  Created by fcl on 15/7/8.
//  Copyright (c) 2015年 李婷. All rights reserved.
//

#import "UIButton+Countdown.h"
#import <objc/runtime.h>

@interface UIButton()

@end

@implementation UIButton (Countdown)



//先要加上label
-(void)addCountdownView {
    
     [self setTitle:@"" forState:UIControlStateNormal];
   UIView *countdownView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    countdownView.backgroundColor=[UIColor clearColor];
    countdownView.tag=1001;
    
    UILabel *countdown=[[UILabel  alloc] initWithFrame:CGRectMake(0, self.frame.size.height/2 -16, self.frame.size.width, 14)];
    countdown.backgroundColor=[UIColor clearColor];
    countdown.tag=1003;
    countdown.textAlignment=NSTextAlignmentCenter;
    countdown.font=[UIFont systemFontOfSize:13];
    countdown.textColor=[UIColor whiteColor];
    countdown.text=@"重新获取";
    [countdownView addSubview:countdown];
    
    UILabel *countdownLB=[[UILabel  alloc] initWithFrame:CGRectMake(0, self.frame.size.height/2 +2, self.frame.size.width/2, 14)];
    countdownLB.backgroundColor=[UIColor clearColor];
    countdownLB.tag=1002;
    countdownLB.textAlignment=NSTextAlignmentRight;
    countdownLB.font=[UIFont systemFontOfSize:13];
    countdownLB.textColor=[UIColor whiteColor];
    countdownLB.text=@"60";
    [countdownView addSubview:countdownLB];
    
    
    UILabel *miaoLB=[[UILabel  alloc] initWithFrame:CGRectMake(self.frame.size.width/2, self.frame.size.height/2 +2, self.frame.size.width/2, 14)];
    miaoLB.backgroundColor=[UIColor clearColor];
    miaoLB.tag=1004;
    miaoLB.textAlignment=NSTextAlignmentLeft;
    miaoLB.font=[UIFont systemFontOfSize:13];
    miaoLB.textColor=[UIColor whiteColor];
    miaoLB.text=@"秒";
    
    [countdownView addSubview:miaoLB];
    
    
    
    [self addSubview:countdownView];
    
}


//移除lable
-(void)deleteCountdownView :(NSString *)title{
     UIView *countdownView =[self viewWithTag:1001];
    [countdownView removeFromSuperview];
     [self setTitle:title forState:UIControlStateNormal];
}


//修改label的值
-(void)setCountdownLBTitle:(NSString *)title{
    UIView *countdownView =[self viewWithTag:1001];
    UILabel *countdownLB =(UILabel *)[countdownView viewWithTag:1002];
    countdownLB.text=title;
}


@end
