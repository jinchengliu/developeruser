//
//  UIButton+Countdown.h
//  ZTRong
//
//  Created by fcl on 15/7/8.
//  Copyright (c) 2015年 李婷. All rights reserved.
//

#import <UIKit/UIKit.h>




@interface UIButton (Countdown)
//@property(nonatomic ,strong)UIView *countdownView;
//@property(nonatomic ,strong)UILabel *countdownLB;
//@property(nonatomic ,strong)NSString *buttonTitle;


-(void)addCountdownView ;

-(void)deleteCountdownView:(NSString *)title;

-(void)setCountdownLBTitle:(NSString *)title;

@end
