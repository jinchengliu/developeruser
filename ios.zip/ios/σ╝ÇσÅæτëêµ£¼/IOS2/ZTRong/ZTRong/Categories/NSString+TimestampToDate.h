//
//  NSString+TimestampToDate.h
//  NewProduct
//
//  Created by zqf on 13-7-9.
//  Copyright (c) 2013年 Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSDate+Category.h"

@interface NSString (MessageTime)

- (NSDate *)timestampToDate;

@end
