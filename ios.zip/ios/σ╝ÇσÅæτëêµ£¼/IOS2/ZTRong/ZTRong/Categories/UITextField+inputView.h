//
//  UITextField+inputView.h
//  ZTRong
//
//  Created by fcl on 15/6/30.
//  Copyright (c) 2015年 李婷. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (inputView)


//键盘右上添加完成按钮
-(void)setinputView;
@end
