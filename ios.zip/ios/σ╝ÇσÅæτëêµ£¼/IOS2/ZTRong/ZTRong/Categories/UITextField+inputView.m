//
//  UITextField+inputView.m
//  ZTRong
//
//  Created by fcl on 15/6/30.
//  Copyright (c) 2015年 李婷. All rights reserved.
//

#import "UITextField+inputView.h"

@implementation UITextField (inputView)



-(void)setinputView{
    UIView *input=[[UIView alloc] initWithFrame:CGRectMake(0, 0, kAppWidth, 44)];
    input.backgroundColor=[UIColor whiteColor];
    UIButton *button=[[UIButton alloc] initWithFrame:CGRectMake(kAppWidth-70, 7, 60, 31)];
    [button setBackgroundImage:[Tool createImageWithColor:[UIColor whiteColor]] forState:UIControlStateNormal];
    [button setTitle:@"完成" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    button.layer.cornerRadius = 5;
    button.layer.masksToBounds = YES;
    button.layer.borderColor=[UIColor lightGrayColor].CGColor;
    button.layer.borderWidth=0.5;
    
    [button handleControlEvent:UIControlEventTouchUpInside withBlock:^{
    
        [self resignFirstResponder];
    
    }];
    
    input.layer.borderColor=[UIColor lightGrayColor].CGColor;
    input.layer.borderWidth=0.5;

    [input addSubview:button];
    
    self.inputAccessoryView=input;
}




@end
