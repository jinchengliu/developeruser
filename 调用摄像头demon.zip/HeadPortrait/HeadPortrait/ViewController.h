//
//  ViewController.h
//  HeadPortrait
//
//  Created by Mr nie on 15/7/26.
//  Copyright (c) 2015年 Mr nie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

